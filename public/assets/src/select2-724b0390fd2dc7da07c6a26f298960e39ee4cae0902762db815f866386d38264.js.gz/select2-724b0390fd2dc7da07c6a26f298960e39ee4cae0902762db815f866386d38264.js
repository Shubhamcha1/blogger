import select2 from "select2" 
let select2 = ()=>{select2()}
;
