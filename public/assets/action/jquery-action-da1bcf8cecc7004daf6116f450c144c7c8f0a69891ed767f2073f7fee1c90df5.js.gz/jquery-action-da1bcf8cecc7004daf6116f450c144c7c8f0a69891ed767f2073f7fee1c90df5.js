

  /*user menu list hide and show action */
 


  /* notification */
  $('#notification').delay(5000).fadeOut('slow');
