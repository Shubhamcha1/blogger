$(function() {
    console.log("hello world")
    $( "#datepicker").datepicker();
   } );

   
